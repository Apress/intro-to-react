var MyClass = React.createClass({

	render: function() {
		return (
                  <div>hello world</div>
                );
	}
});
//or using ES6 classes such as
class MyClass extends React.Component {

	render() {
 		return <div>hello world</div>;
        }
}
