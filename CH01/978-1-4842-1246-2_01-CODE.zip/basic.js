/* example without JSX */
React.render(
    React.createElement('div', null,
        React.createElement('h1', null, 'Header')
    );
);

