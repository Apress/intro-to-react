// JSX version

React.render(
    <div>
        <h1>Header</h1>
    </div>
);
